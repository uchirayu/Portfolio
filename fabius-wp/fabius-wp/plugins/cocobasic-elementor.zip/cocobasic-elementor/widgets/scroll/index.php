<?php

namespace CocoBasicElements\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\utils;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class coco_scroll extends Widget_Base {

    public function get_name() {
        return 'coco-scroll';
    }

    public function get_title() {
        return esc_attr__('Scroll', 'cocobasic-elementor');
    }

    public function get_icon() {
        return 'fa fa-th';
    }

    public function get_categories() {
        return array('coco-element');
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_general', [
            'label' => esc_attr__('General', 'cocobasic-elementor'),
            'tab' => Controls_Manager::TAB_STYLE,
                ]
        );

        $this->add_control(
                'scroll_background_color', [
            'label' => esc_attr__('Background color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .icon-scroll:after' => 'background-color: {{VALUE}};',
            ],
                ]
        );
        
        $this->add_control(
                'scroll_color', [
            'label' => esc_attr__('Color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .icon-scroll' => 'box-shadow: inset 0 0 0 3px {{VALUE}};',
                '{{WRAPPER}} .icon-scroll:before' => 'background-color: {{VALUE}};',
            ],
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        require dirname(__FILE__) . '/view.php';
    }

}

$widgets_manager->register_widget_type(new \CocoBasicElements\Widgets\coco_scroll());
