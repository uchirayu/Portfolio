<?php

$num = $settings['num'] ? $settings['num'] : '5';
$all_text = $settings['all_text'] ? $settings['all_text'] : 'All';
$show_filter = $settings['show_filter'] ? $settings['show_filter'] : 'false';

$loadmore_text = $settings['loadmore_text'] ? $settings['loadmore_text'] : '';
$loadmore_loading_text = $settings['loadmore_loading_text'] ? $settings['loadmore_loading_text'] : '';
$loadmore_nomore_text = $settings['loadmore_nomore_text'] ? $settings['loadmore_nomore_text'] : '';
$view_more_text = $settings['view_more_text'] ? $settings['view_more_text'] : '';

global $post;
$args = array('post_type' => 'portfolio', 'post_status' => 'publish', 'posts_per_page' => $num);
$loop = new WP_Query($args);

$return = '<div id="portfolio-wrapper" class="relative">';

if ($show_filter === 'true') {
    $return .= '<div class="category-filter-list button-group filters-button-group animate">
                <div class="button is-checked" data-filter="*">' . $all_text . '</div>
                ' . drop_cats_filter() . '
            </div>';
}

if ($loop->have_posts()) :
    $return .= '<div class="portfolio-load-content-holder content-670"></div><div class="grid" id="portfolio-grid" data-text="' . esc_html($view_more_text) . '">';
    while ($loop->have_posts()) : $loop->the_post();
        if (has_post_thumbnail($post->ID)) {
            $portfolio_post_thumb = get_the_post_thumbnail($post->ID, 'medium_large');
        } else {
            $portfolio_post_thumb = '<img src = "' . PM_PLUGIN_URL . 'assets/images/no-photo.png" alt = "" />';
        }

        if (get_post_meta($post->ID, "portfolio_hover_thumb_title", true) != ''):
            $p_thumb_title = get_post_meta($post->ID, "portfolio_hover_thumb_title", true);
        else:
            $p_thumb_title = get_the_title();
        endif;

        $link_thumb_to = get_post_meta($post->ID, "portfolio_link_item_to", true);
        $excerpt_text = get_post_meta($post->ID, "portfolio_excerpt_text", true);

        switch ($link_thumb_to):
            case 'link_to_this_post_regular':
                $return .= '<div class="grid-item element-item animate ' . drop_cats_slug($post->ID) . '"><a class="item-link portfolio-image-link" href="' . get_permalink() . '">';
                $portfolio_link_structure = '<a class="item-link" href="' . get_permalink() . '">';
                break;
            case 'link_to_image_url':
                $image_popup = get_post_meta($post->ID, "portfolio_image_popup", true);
                $return .= '<div class="grid-item element-item animate ' . drop_cats_slug($post->ID) . '"><a class="item-link portfolio-image-link" href="' . $image_popup . '" data-rel="prettyPhoto[portfolio1]">';
                $portfolio_link_structure = '<a class="item-link" href="' . $image_popup . '" data-rel="prettyPhoto[portfolio1]">';
                break;
            case 'link_to_video_url':
                $video_popup = get_post_meta($post->ID, "portfolio_video_popup", true);
                $return .= '<div class="grid-item element-item animate ' . drop_cats_slug($post->ID) . '"><a class="item-link portfolio-image-link" href="' . $video_popup . '" data-rel="prettyPhoto[portfolio1]">';
                $portfolio_link_structure = '<a class="item-link" href="' . $video_popup . '" data-rel="prettyPhoto[portfolio1]">';
                break;
            case 'link_to_extern_url':
                $extern_site_url = get_post_meta($post->ID, "portfolio_extern_site_url", true);
                $return .= '<div class="grid-item element-item animate ' . drop_cats_slug($post->ID) . '"><a class="item-link portfolio-image-link" href="' . $extern_site_url . '" target="_blank">';
                $portfolio_link_structure = '<a class="item-link" href="' . $extern_site_url . '" target="_blank">';
                break;
            default:
                $return .= '<div id="p-item-' . $post->ID . '" class="grid-item element-item animate ' . drop_cats_slug($post->ID) . '"><a class="item-link ajax-portfolio portfolio-image-link" href="' . get_permalink() . '" data-id="' . $post->ID . '">';
                $portfolio_link_structure = '<a class="item-link ajax-portfolio" href="' . get_permalink() . '" data-id="' . $post->ID . '">';
        endswitch;

        $return .= '<div class="portfolio-image">' . $portfolio_post_thumb . '</div></a><div class="portfolio-text-wrapper"><h3 class="portfolio-title">' . $portfolio_link_structure . '' . $p_thumb_title . '</a></h3><div class="portfolio-excerpt">' . $excerpt_text . '</div><div class="portfolio-view-more">' . $portfolio_link_structure . '' . $view_more_text . '</a></div></div></div>';

    endwhile;

    $return .= '</div>';
endif;
$return .= '<div class="clear"></div></div>';
$return .= '<div class = "block more-posts-portfolio-holder animate"><span class = "more-posts-portfolio">' . $loadmore_text . '</span><span class = "more-posts-portfolio-loading">' . $loadmore_loading_text . '</span><span class = "no-more-posts-portfolio">' . $loadmore_nomore_text . '</span></div>';
wp_reset_postdata();
echo $return;
?>                                                