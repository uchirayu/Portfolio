<?php

namespace CocoBasicElements\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\utils;
use Elementor\Repeater;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class coco_timeline extends Widget_Base {

    public function get_name() {
        return 'coco-timeline';
    }

    public function get_title() {
        return esc_attr__('Timeline', 'cocobasic-elementor');
    }

    public function get_icon() {
        return 'fa fa-th';
    }

    public function get_categories() {
        return array('coco-element');
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_process_1', [
            'label' => esc_attr__('Content', 'cocobasic-elementor'),
                ]
        );

        $this->add_control(
                'quote_img', [
            'label' => esc_attr__('Quote Image', 'cocobasic-elementor'),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
            'label_block' => true,
                ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'event_content', [
            'label' => esc_attr__('Timeline Content', 'cocobasic-elementor'),
            'type' => Controls_Manager::WYSIWYG,
            'label_block' => true,
            'default' => esc_attr__('Timeline Content', 'cocobasic-elementor'),
                ]
        );

        $this->add_control(
                'items', [
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'prevent_empty' => false,
            'default' => [
                [
                    'title' => esc_attr__('Timeline Content', 'cocobasic-elementor'),
                ]
            ],
            'title_field' => '{{{ title }}}',
                ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
                'section_general', [
            'label' => esc_attr__('General', 'cocobasic-elementor'),
            'tab' => Controls_Manager::TAB_STYLE,
                ]
        );

        $this->add_control(
                'content_color', [
            'label' => esc_attr__('Content color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .timeline-holder li p' => 'color: {{VALUE}};',
            ],
                ]
        );
        
         $this->add_control(
                'content_background_color', [
            'label' => esc_attr__('Content background color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .timeline-holder li' => 'background-color: {{VALUE}};',
            ],
                ]
        );

        $this->add_group_control(
                Group_Control_Typography::get_type(), [
            'name' => 'content_typography',
            'label' => esc_attr__('Content Typography', 'cocobasic-elementor'),
            'selector' => '{{WRAPPER}} .timeline-holder li p',
                ]
        );

        $this->add_control(
                'line_color', [
            'label' => esc_attr__('Lines color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .timeline-holder:before' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .timeline-holder li:before' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .timeline-holder li .marker' => 'border-color: {{VALUE}};',
                '{{WRAPPER}} .timeline-holder li:hover .marker' => 'background-color: {{VALUE}};'
            ],
                ]
        );
                
        $this->add_control(
                'circle_background_color', [
            'label' => esc_attr__('Circle Background color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .timeline-holder li:after' => 'background-color: {{VALUE}};'                
            ],
                ]
        );
        
         $this->add_control(
                'event_border_radius', [
            'label' => esc_attr__('Event Border Radius', 'cocobasic-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%'],
            'selectors' => [
                '{{WRAPPER}} .timeline-holder li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'                
            ],
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        require dirname(__FILE__) . '/view.php';
    }

    private function content($content) {
        $quoteImg = $this->get_settings();
        $quoteImg = wp_get_attachment_image($quoteImg["quote_img"]["id"]);
        $out = '';

        foreach ($content as $item) {

            $event_content = $item['event_content'] ? $item['event_content'] : '';
            $out .= '
                <li class="animate">  
                    <div class="quote-image">' . $quoteImg . '</div>
                    <div>' . $event_content . '</div>                    
                    <span class="marker"></span>
                </li>          
            ';
        }

        return $out;
    }

}

$widgets_manager->register_widget_type(new \CocoBasicElements\Widgets\coco_timeline());
