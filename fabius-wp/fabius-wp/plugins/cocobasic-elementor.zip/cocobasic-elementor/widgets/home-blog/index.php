<?php

namespace CocoBasicElements\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\utils;

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

class coco_blog extends Widget_Base {

    public function get_name() {
        return 'coco-blog';
    }

    public function get_title() {
        return esc_attr__('Latest Posts', 'cocobasic-elementor');
    }

    public function get_icon() {
        return 'fa fa-th';
    }

    public function get_categories() {
        return array('coco-element');
    }

    protected function _register_controls() {

        $this->start_controls_section(
                'section_process_1', [
            'label' => esc_attr__('Content', 'cocobasic-elementor'),
                ]
        );

        $this->add_control(
                'num', [
            'label' => esc_attr__('Number of items to show', 'cocobasic-elementor'),
            'type' => Controls_Manager::TEXT,
            'label_block' => true,
            'default' => esc_attr__('2', 'cocobasic-elementor'),
                ]
        );

        $this->add_control(
                'excerpt', [
            'label' => esc_attr__('Show excerpt', 'cocobasic-elementor'),
            'type' => Controls_Manager::SELECT,
            'label_block' => true,
            'options' => [
                'true' => esc_attr__('Yes', 'cocobasic-elementor'),
                'false' => esc_attr__('No', 'cocobasic-elementor'),
            ],
            'default' => 'true',
                ]
        );

        $this->add_control(
                'excerpt_lenght', [
            'label' => esc_attr__('Excerpt lenght', 'cocobasic-elementor'),
            'type' => Controls_Manager::TEXT,
            'label_block' => true,
            'default' => esc_attr__('20', 'cocobasic-elementor'),
                ]
        );

        $this->add_control(
                'read_more', [
            'label' => esc_attr__('More Indicator', 'cocobasic-elementor'),
            'type' => Controls_Manager::TEXT,
            'label_block' => true,
            'default' => esc_attr__(' ...', 'cocobasic-elementor'),
                ]
        );

        $this->add_control(
                'read_more_text', [
            'label' => esc_attr__('Read More Text', 'cocobasic-elementor'),
            'type' => Controls_Manager::TEXT,
            'label_block' => true,
            'default' => esc_attr__('READ MORE', 'cocobasic-elementor'),
                ]
        );
        
          $this->add_control(
                'image_height', [
            'label' => esc_attr__('Image height', 'cocobasic-elementor'),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'unit' => 'px',
            ],
            'tablet_default' => [
                'unit' => 'px',
            ],
            'mobile_default' => [
                'unit' => 'px',
            ],
            'size_units' => [ 'px'],
            'range' => [
                'px' => [
                    'min' => 100,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .home-blog-list li img' => 'height: {{SIZE}}{{UNIT}};',                
            ],
                ]
        );

        $this->add_control(
                'image_border_radius', [
            'label' => esc_attr__('Image Border Radius', 'cocobasic-elementor'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => [ 'px', '%'],
            'selectors' => [
                '{{WRAPPER}} .home-blog-list .home-blog-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .home-blog-list li img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
                ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
                'section_general', [
            'label' => esc_attr__('General', 'cocobasic-elementor'),
            'tab' => Controls_Manager::TAB_STYLE,
                ]
        );

        $this->add_control(
                'title_color', [
            'label' => esc_attr__('Title color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .home-blog-list li h4 a' => 'color: {{VALUE}};',
            ],
                ]
        );

        $this->add_control(
                'title_hover_color', [
            'label' => esc_attr__('Title hover color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .home-blog-list li h4 a:hover' => 'color: {{VALUE}};',
            ],
                ]
        );

        $this->add_group_control(
                Group_Control_Typography::get_type(), [
            'name' => 'title_typography',
            'label' => esc_attr__('Title Typography', 'cocobasic-elementor'),
            'selector' => '{{WRAPPER}} .home-blog-list li h4 a',
                ]
        );

        $this->add_control(
                'excerpt_color', [
            'label' => esc_attr__('Excerpt color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .home-blog-list .home-blog-excerpt' => 'color: {{VALUE}};',
            ],
                ]
        );

        $this->add_group_control(
                Group_Control_Typography::get_type(), [
            'name' => 'excerpt_typography',
            'label' => esc_attr__('Excerpt Typography', 'cocobasic-elementor'),
            'selector' => '{{WRAPPER}} .home-blog-list .home-blog-excerpt',
                ]
        );

        $this->add_control(
                'read_more_color', [
            'label' => esc_attr__('Read More color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} a.home-blog-read-more' => 'color: {{VALUE}};',
                '{{WRAPPER}} a.home-blog-read-more:after ' => 'background-color: {{VALUE}};',
            ],
                ]
        );
      
        $this->add_control(
                'read_more_hover_color', [
            'label' => esc_attr__('Read More hover color', 'cocobasic-elementor'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} a.home-blog-read-more:hover' => 'color: {{VALUE}};',
                '{{WRAPPER}} a.home-blog-read-more:hover:after ' => 'background-color: {{VALUE}};',
            ],
                ]
        );

        $this->add_group_control(
                Group_Control_Typography::get_type(), [
            'name' => 'read_more_typography',
            'label' => esc_attr__('Read More Typography', 'cocobasic-elementor'),
            'selector' => '{{WRAPPER}} a.home-blog-read-more',
                ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings();
        require dirname(__FILE__) . '/view.php';
    }

}

$widgets_manager->register_widget_type(new \CocoBasicElements\Widgets\coco_blog());
