<?php

$num = $settings['num'] ? $settings['num'] : '5';
$excerpt = $settings['excerpt'] ? $settings['excerpt'] : 'true';

$more = $settings['read_more'] ? $settings['read_more'] : '';
$more_text = $settings['read_more_text'] ? $settings['read_more_text'] : '';
$excerpt_lenght = $settings['excerpt_lenght'] ? $settings['excerpt_lenght'] : '20';
$excerpt_lenght = (int) $excerpt_lenght;


global $post;
$args = array('post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => $num);
$loop = new WP_Query($args);

$return = '<ul class="home-blog-list">';
if ($loop->have_posts()) :
    while ($loop->have_posts()) : $loop->the_post();

        $return .= '<li>';
        if (has_post_thumbnail()):
            $return .= '<div class="home-blog-image">';
            $return .= '<a class="home-blog-image-link" href="' . get_permalink($post->ID) . '" title="' . esc_attr($post->post_title) . '">';
            $return .= get_the_post_thumbnail($post->ID, 'medium_large');
            $return .= '</a>';
            $return .= '</div>';
        endif;

        $return .= '<div class="home-blog-text-wrapper">';

        $return .= '<h4 class="entry-title"><a class="entry-title-link" href="' . get_permalink() . '">' . get_the_title() . '</a></h4>';

        if ($excerpt === 'true'):
            $return .= '<div class="home-blog-excerpt">' . cocobasic_excerpt($excerpt_lenght, $more) . '</div>';
        endif;

        $return .= '<a class="home-blog-read-more" href="' . get_permalink() . '">' . $more_text . '</a>';

        $return .= '</div>';
        $return .= '</li>';

    endwhile;

    $return .= '</ul>';
endif;
wp_reset_postdata();
echo $return;
?>                                                