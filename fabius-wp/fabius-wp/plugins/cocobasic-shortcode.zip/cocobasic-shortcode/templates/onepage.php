<?php
/*
 * Template Name: OnePage 
 */
?>

<?php get_header(); ?>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?> >   
    <div class="one-page-content-wrapper content-holder content-960 center-relative">                
        <?php
        if (have_posts()) :
            while (have_posts()) : the_post();
                the_content();
            endwhile;
        endif;
        ?>
    </div>
</div>

<?php get_footer(); ?>