<?php get_header(); ?>
<div id="content" class="site-content">      
    <div id="post-<?php the_ID(); ?>" <?php post_class(); ?> >
        <div class="content-holder center-relative content-960">
            <?php
            global $post;

            if (isset($_POST["action"]) && ($_POST["action"] === 'portfolio_ajax_content_load')):
                if ($portfolio_query->have_posts()) :
                    while ($portfolio_query->have_posts()) : $portfolio_query->the_post();
                        echo '<div class="portfolio-content">';
                        the_content();
                        echo '</div>';
                    endwhile;
                endif;
            else:
                if (have_posts()) :
                    while (have_posts()) : the_post();
                        echo '<div class="portfolio-content">';
                        the_content();
                        echo '</div>';
                    endwhile;
                endif;

            endif;
            ?>
            <div class="clear"></div>        
        </div>
    </div>
</div>
<?php get_footer(); ?>